## [0.0.1] - Alpha Release

* Beautiful Music Player with all basic functionalities.
* Minor Bugs
* Only Android support as of now.
