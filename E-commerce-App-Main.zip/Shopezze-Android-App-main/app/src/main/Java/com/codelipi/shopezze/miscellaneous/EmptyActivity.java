package com.codelipi.ecomm.miscellaneous;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.codelipi.ecomm.R;
public class EmptyActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);
    }
}
