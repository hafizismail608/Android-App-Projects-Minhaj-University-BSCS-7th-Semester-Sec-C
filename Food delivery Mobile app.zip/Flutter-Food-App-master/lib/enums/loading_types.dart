enum LoadingType { stable,loading, loaded, completed, error }
