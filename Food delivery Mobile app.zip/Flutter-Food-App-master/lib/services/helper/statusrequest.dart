enum StatusRequest {
  loading , 
  success , 
  failure , 
  serverfailure , 
  offlinefailure ,
  stop
}