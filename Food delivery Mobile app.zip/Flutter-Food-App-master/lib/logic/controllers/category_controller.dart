import 'package:get/get.dart';

import '../../services/restaurant_services.dart';

class CategoryController extends GetxController {
  
}
