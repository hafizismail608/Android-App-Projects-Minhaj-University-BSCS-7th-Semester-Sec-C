# Food App Flutter

#### complete food app, where I will share with you how you can create a nice clean screens for your app that can run both Andriod and iOS devices because it builds with #flutter.

# Screens it contains:

=> Onboarding

=> Login

=> Forgot Password

=> Sign Up

=> Complete Profile

=> OTP Verification

=> Home Page

=> Product Details

=> Order

=> Profile

=> Bottom Navigation Bar

# Photos

![smartmockups_l7iv6lpr](https://user-images.githubusercontent.com/80541747/187887904-9ddfb62a-a7e6-4c79-994f-c62c54cf8474.jpg)
![smartmockups_l7iva5v9](https://user-images.githubusercontent.com/80541747/187887916-f583f499-40d8-4f78-a22e-0de664ed46af.jpg)
![1](https://user-images.githubusercontent.com/80541747/187887924-313c4bac-8a70-490e-ad1c-acae4d606ec1.jpg)
![4](https://user-images.githubusercontent.com/80541747/187887933-a9780d44-6dcf-409c-90da-4920d62f33fb.jpg)
![smartmockups_l7iut7cz](https://user-images.githubusercontent.com/80541747/187887939-d8613f74-933a-43b8-a1f1-0a7f55b31f0d.jpg)
![smartmockups_l7iuvt0p](https://user-images.githubusercontent.com/80541747/187887987-55f33e57-d964-46e6-8dfa-2d77d4b938d0.jpg)
![2](https://user-images.githubusercontent.com/80541747/187888012-c4e62a83-72cf-4281-b89b-2e2e4985e152.jpg)
![3](https://user-images.githubusercontent.com/80541747/187888023-48b67ada-069d-4a92-b72a-e229b9c92f4d.jpg)
![smartmockups_l7iuxmzi](https://user-images.githubusercontent.com/80541747/187888058-a4f0695a-401d-428b-ab15-07b8080e78f2.jpg)
![smartmockups_l7iuy4bg](https://user-images.githubusercontent.com/80541747/187888086-c71c4242-957b-4d79-8854-a920d6aabe9e.jpg)
![smartmockups_l7iuyq71](https://user-images.githubusercontent.com/80541747/187888094-fe3aed3d-07da-4c88-9b2b-10b9f6638d42.jpg)
![smartmockups_l7iuwbw6](https://user-images.githubusercontent.com/80541747/187888099-4939e0fe-b45c-4d85-a0a9-2c022533427e.jpg)
![smartmockups_l7iux1e3](https://user-images.githubusercontent.com/80541747/187888105-855c9f03-a216-4eec-b448-f099b0c474e1.jpg)
![smartmockups_l7iv1ji3](https://user-images.githubusercontent.com/80541747/187888112-f4fac711-6b5f-4edf-adc6-3657aaf177da.jpg)
![smartmockups_l7iv07f2](https://user-images.githubusercontent.com/80541747/187888119-7effd980-8091-43d5-8307-17dac9d99be6.jpg)


