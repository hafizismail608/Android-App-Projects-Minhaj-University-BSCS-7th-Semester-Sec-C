package com.example.myapp;

public class forecastModel {

    String key;
    String q;
    String aqi;
    int days;
    String alert
}
